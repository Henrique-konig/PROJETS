from App import Pessoa, Estudante, Professor, Coordenador
import time
import random

print(10*"-", "ENTRANDO NO SISTEMA", 10*"-")
time.sleep(2)

pessoas = []
estudantes = []
professores = []
coordenadores = []

while True:
    print(20*"=", "MENU DE GERENCIAMENTO ESCOLAR", 20*"=")
    print("1 - Gerenciar Estudante")
    print("2 - Buscar informações de estudantes")
    print("3 - Gerenciar Professor")
    print("4 - Buscar informações de professor")
    print("5 - Gerenciar Coordenador")
    print("6 - Buscar informações de coordenador")
    print("7 - Sair")

    esc = int(input("ESCOLHA UMA DAS OPÇÕES.\nResponda aqui: "))

    if esc == 1:  
        nome = input("Informe o nome do aluno: ")
        idade = int(input("Informe a idade do aluno: "))
        telefone = int(input("Informe o telefone do aluno: "))
        matricula = random.randint(1, 1000)
        nota = float(input("Informe a média do aluno: "))

        aluno = Estudante(nome, idade, telefone, matricula, nota)
        estudantes.append(aluno)
        print("Estudante cadastrado com sucesso!\n")

    elif esc == 2:
        if not estudantes:
            print("Nenhum estudante cadastrado ainda.\n")
        else:
            print(10*"=", "INFORMAÇÕES DOS ESTUDANTES", 10*"=")
            for aluno in estudantes:
                aluno.mostrarInformacoes()
                print()

    elif esc == 3:
        nome = input("Informe o nome do professor: ")
        idade = int(input("Informe a idade do professor: "))
        telefone = int(input("Informe o telefone do professor: "))
        disciplina = input("Informe a disciplina do professor: ")
        salario = float(input("Informe o salário do professor: "))

        prof = Professor(nome, idade, telefone, disciplina, salario)
        professores.append(prof)
        print("Professor cadastrado com sucesso!\n")

    elif esc == 4:
        if not professores:
            print("Nenhum professor cadastrado ainda.\n")
        else:
            print(10*"=", "INFORMAÇÕES DOS PROFESSORES", 10*"=")
            for prof in professores:
                prof.mostrarInformacoes()
                print()

    elif esc == 5:
        nome = input("Informe o nome do coordenador: ")
        idade = int(input("Informe a idade do coordenador: "))
        telefone = int(input("Informe o telefone do coordenador: "))
        departamento = input("Informe o departamento: ")
        bonus = float(input("Informe o bônus: "))

        coord = Coordenador(nome, idade, telefone, departamento, bonus)
        coordenadores.append(coord)
        print("Coordenador cadastrado com sucesso!\n")

    elif esc == 6:
        if not coordenadores:
            print("Nenhum coordenador cadastrado ainda.\n")
        else:
            print(10*"=", "INFORMAÇÕES DOS COORDENADORES", 10*"=")
            for coord in coordenadores:
                coord.mostrarInformacoes()
                print()

    elif esc == 7:
        print("Encerrando o sistema.")
        break