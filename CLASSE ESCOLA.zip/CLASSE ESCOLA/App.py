class Pessoa:
    def __init__(self, nome, idade, telefone):
        self.nome = nome
        self.idade = idade
        self.telefone = telefone

    def mostrarInformacoes(self):
        print(f"Nome: {self.nome}")
        print(f"Idade: {self.idade}")
        print(f"Telefone: {self.telefone}")

class Estudante(Pessoa):
    def __init__(self, nome, idade, telefone, matricula, notaMedia):
        super().__init__(nome, idade, telefone)
        self.matricula = matricula
        self.notaMedia = notaMedia

    def mostrarInformacoes(self):
        super().mostrarInformacoes()
        print(f"Matrícula: {self.matricula}")
        print(f"Nota Média: {self.notaMedia}")

class Professor(Pessoa):
    def __init__(self, nome, idade, telefone, disciplina, salario):
        super().__init__(nome, idade, telefone)
        self.disciplina = disciplina
        self.salario = salario

    def mostrarInformacoes(self):
        super().mostrarInformacoes()
        print(f"Disciplina: {self.disciplina}")
        print(f"Salário: {self.salario}")

class Coordenador(Pessoa):
    def __init__(self, nome, idade, telefone, departamento, bonus):
        super().__init__(nome, idade, telefone)
        self.departamento = departamento
        self.bonus = bonus

    def mostrarInformacoes(self):
        super().mostrarInformacoes()
        print(f"Departamento: {self.departamento}")
        print(f"Bônus: {self.bonus}")
